-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : mer. 10 mai 2023 à 09:37
-- Version du serveur : 8.0.31
-- Version de PHP : 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `cda2023magnet`
--

-- --------------------------------------------------------

--
-- Structure de la table `article`
--

DROP TABLE IF EXISTS `article`;
CREATE TABLE IF NOT EXISTS `article` (
  `id_article` int NOT NULL AUTO_INCREMENT,
  `title_article` varchar(255) NOT NULL,
  `content_article` text NOT NULL,
  `date_article` datetime NOT NULL,
  `image_article` varchar(255) NOT NULL,
  PRIMARY KEY (`id_article`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `article`
--

INSERT INTO `article` VALUES(1, 'Mon article', 'Test de l\'article', '2023-05-09 14:53:07', '645a5e53081d1.jpg');
INSERT INTO `article` VALUES(2, 'Deuxième article', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus ut ex risus. Nunc eleifend mi et elit sollicitudin, vel hendrerit metus tempus. Suspendisse vel arcu sit amet odio rhoncus ullamcorper vel eu lectus. Praesent luctus, mauris non mollis scelerisque, tortor metus venenatis arcu, sit amet iaculis ligula libero efficitur mauris. Sed eleifend odio et dignissim faucibus. Mauris at eros feugiat, lacinia eros sed, pretium tellus. Donec ut elit et massa condimentum vestibulum. Ut finibus eu augue at mattis. Vivamus non nulla sit amet lacus condimentum tempus a ac neque. Suspendisse potenti. Mauris et pharetra sem. Aliquam erat volutpat.\r\n\r\nDuis pharetra, augue non venenatis maximus, ipsum eros fringilla justo, consequat pharetra turpis enim non enim. Ut aliquam orci quam, non auctor metus lacinia in. Maecenas sollicitudin justo at orci pharetra elementum. Aliquam consectetur sodales libero id aliquam. Quisque eget lacinia felis, in ultrices lorem. Maecenas sed pharetra elit. Proin maximus tempor quam id eleifend. Pellentesque posuere ante massa, ut consectetur lectus mattis et. Vestibulum pretium nisi urna, at finibus velit egestas eu. Integer egestas, arcu non scelerisque efficitur, sapien dolor mollis eros, quis fringilla justo mi non urna. Fusce dapibus imperdiet risus in cursus. Praesent in neque venenatis, laoreet enim id, convallis elit. Cras sodales ullamcorper lacus id finibus. Pellentesque sollicitudin pharetra erat, non tempus odio varius nec.\r\n\r\nSed eros justo, laoreet eget ex ut, aliquet venenatis lorem. Sed quis congue felis. Aenean at vulputate purus. Maecenas luctus ligula augue, eu cursus lacus pharetra non. Praesent at orci non lacus mattis volutpat et a mi. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Suspendisse aliquet eget libero in dictum. Integer a libero nec ante ornare lacinia. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Phasellus at posuere risus. Nam sed posuere lorem, eu eleifend magna. Integer porta faucibus leo, in sagittis erat. Fusce dolor enim, facilisis eu leo vitae, aliquam venenatis lacus.\r\n\r\nVestibulum at suscipit elit, sagittis posuere nunc. Morbi consequat nulla vel eros mattis, et convallis est rhoncus. Duis ut fermentum tortor. Pellentesque vitae malesuada felis. Nunc at libero non libero varius luctus ut vitae est. Curabitur porttitor mi semper lacus posuere porta. Ut lacus risus, lacinia ac consequat sed, varius in risus.\r\n\r\nAenean varius gravida velit ut accumsan. Etiam viverra sit amet lectus sed bibendum. Vivamus luctus libero sed facilisis accumsan. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Sed tincidunt tempor sem, sed luctus tortor feugiat ac. Mauris porta libero lacus, non lacinia nisl faucibus ut. Curabitur congue scelerisque lectus, nec maximus ligula ullamcorper non. Suspendisse tempus dignissim gravida. Cras elit mi, ultricies sed augue mattis, rhoncus scelerisque tortor. Nunc viverra aliquam lacus eu facilisis. Duis nec neque non dui dapibus euismod sed vel nisl. Nullam id ante ullamcorper, consectetur lectus nec, viverra risus. Donec vel tincidunt nisl, nec molestie nisi. Phasellus lectus eros, fermentum ut venenatis a, molestie id metus. Nunc posuere viverra tortor, nec feugiat eros auctor eu.', '2023-05-10 07:20:30', '645b45be2f47b.jpg');
INSERT INTO `article` VALUES(3, 'Troisième article', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec at est sit amet est sagittis finibus. Duis vel magna sit amet nunc varius accumsan. In ultrices sollicitudin ipsum vitae molestie. Pellentesque interdum tincidunt lectus, ut convallis est gravida sit amet. Vivamus ligula odio, sagittis in varius iaculis, fringilla ut elit. Nullam cursus dapibus lectus et pretium. Sed finibus mattis nunc, blandit convallis diam laoreet sit amet. Praesent nec ante ante.\r\n\r\nPhasellus euismod elit id odio tristique, vitae malesuada eros gravida. Integer at nibh tristique, consectetur leo id, volutpat mauris. Integer consequat accumsan neque scelerisque vehicula. Suspendisse lacinia neque dolor, sed fermentum lorem vehicula et. Aliquam at ligula ut elit dignissim sagittis. Quisque elementum, nunc sit amet porttitor pulvinar, lacus sem vestibulum purus, vitae convallis augue purus et diam. Duis consequat eget dui a placerat. Vestibulum justo neque, convallis ac mattis at, lacinia nec enim. Morbi dapibus bibendum arcu vitae mattis. Sed consectetur auctor fringilla. Duis egestas lorem lorem, at auctor lectus pharetra quis.\r\n\r\nProin sagittis sodales venenatis. Nunc tristique, libero a mattis scelerisque, magna neque posuere quam, ut aliquam eros enim sit amet erat. Nulla vitae eleifend augue. Cras placerat odio tellus, id semper elit varius in. Pellentesque tempor ac mauris consequat eleifend. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec fringilla arcu neque, eu ultricies ligula sagittis ut. Nam mollis, orci eget accumsan varius, felis dolor aliquet mi, quis vehicula orci nibh id dolor. Donec convallis iaculis mi id elementum. Duis tristique odio at quam consequat hendrerit. Maecenas finibus nunc erat, id euismod eros hendrerit sit amet. Phasellus pretium velit at libero tempus, non posuere nibh blandit. Suspendisse a mauris tincidunt, varius orci non, fermentum dolor. Duis et ipsum eu orci accumsan efficitur. Aliquam nunc ante, feugiat vitae luctus et, accumsan condimentum augue. Ut massa arcu, bibendum eu augue vel, aliquam varius ligula.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Donec urna diam, fringilla ut nunc ut, tincidunt convallis velit. Sed ullamcorper nibh sit amet nunc commodo, eget vulputate sem tincidunt. Sed nec tempor nunc, id blandit mi. Aliquam diam purus, pellentesque a ex eu, faucibus eleifend odio. Nulla in purus nec tellus dapibus dignissim. Vivamus vel nisl purus. In hac habitasse platea dictumst. Mauris rhoncus nibh nec lorem suscipit, a dignissim mauris convallis. Aenean a ligula dui. Nulla sit amet mi ultrices augue tincidunt lacinia. Sed tincidunt libero at lacus pellentesque, eget lobortis dui ullamcorper. Maecenas eros turpis, iaculis vel orci sed, dapibus bibendum nunc. Integer et mi erat. Donec sagittis auctor ipsum, et efficitur elit dictum ac.\r\n\r\nDuis interdum erat eu elit dapibus, a fringilla magna egestas. Quisque id tellus vel est condimentum ultrices. Fusce vitae vehicula nunc. Proin gravida mi at sapien bibendum venenatis. Sed viverra vitae ante a ullamcorper. Vivamus at ipsum ut dui porta scelerisque. Nullam ac sodales ex. Nam suscipit dapibus diam, eu tristique lorem ornare eu. Etiam libero turpis, congue non metus sit amet, molestie elementum lorem.', '2023-05-10 07:20:50', '645b5f300e0fb.png');
INSERT INTO `article` VALUES(4, 'Quatrième article', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla facilisis hendrerit diam, a laoreet quam fringilla et. Nullam dui urna, mollis quis nulla at, elementum sollicitudin est. Suspendisse scelerisque consectetur magna, ac dignissim orci. Mauris luctus porttitor erat, at faucibus nulla interdum in. Cras suscipit arcu a lectus facilisis placerat. Cras quis vestibulum odio. Maecenas ac lectus at purus facilisis placerat a sed ex. Nunc ac dui nibh.\r\n\r\nPhasellus feugiat diam nisl, ut tempus purus consequat et. Mauris gravida molestie dui eu mattis. Morbi euismod tristique pharetra. In vehicula quis ante id volutpat. Morbi semper pharetra sapien, vitae tempus ex. In sit amet luctus libero. Donec massa metus, tristique vel euismod vel, auctor at urna. Pellentesque nulla ipsum, molestie at tellus quis, lacinia faucibus quam. Duis ac eros dapibus, convallis risus euismod, porta lectus. Nulla maximus sagittis est, quis cursus erat porttitor id.\r\n\r\nInteger feugiat est porta enim volutpat efficitur ornare at ipsum. Suspendisse potenti. Praesent vitae vehicula elit. Vestibulum varius eros vel eros malesuada facilisis. Duis nec enim vitae libero condimentum aliquam. Interdum et malesuada fames ac ante ipsum primis in faucibus. Nam ornare nulla tristique, convallis nunc ut, aliquam purus. Quisque quis dignissim ex.\r\n\r\nIn tempus risus at dui maximus ultricies. Aliquam leo leo, ultricies a leo at, venenatis interdum diam. Nulla nec fringilla elit. Curabitur bibendum lacus id auctor suscipit. Nullam mauris sapien, dictum blandit feugiat sodales, suscipit vel nibh. Fusce sed libero ac quam luctus euismod id quis libero. Donec in accumsan massa. Sed at vehicula felis. Vestibulum auctor vel velit nec lobortis. Donec vestibulum dui est, vitae hendrerit lorem ultrices non. Curabitur lobortis augue efficitur, sollicitudin libero ut, pretium tortor. In vitae arcu mattis, eleifend massa quis, pulvinar elit.\r\n\r\nDonec sit amet urna in lectus semper hendrerit. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras eget massa ut lectus lobortis tempus. Curabitur mattis purus vitae neque tincidunt, lacinia molestie massa rhoncus. Suspendisse potenti. Praesent convallis eros risus, a tincidunt neque semper eu. Nam dictum felis at vulputate mollis.', '2023-05-10 07:21:11', '645b45e7ceb90.png');
INSERT INTO `article` VALUES(5, 'Cinquième article', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum sed fermentum sapien. Quisque non dignissim lectus, eu ultricies neque. Pellentesque nec velit hendrerit, volutpat ex ac, fermentum justo. Praesent eu metus a ipsum pulvinar tempus ac vitae neque. Vestibulum tincidunt consectetur eros, a gravida tortor eleifend in. Donec laoreet ligula eu cursus consequat. Pellentesque sit amet nibh vitae eros porta convallis quis a arcu. Nullam at purus cursus, viverra nibh vel, fringilla ex. Aliquam luctus euismod sapien, ut placerat nisi sagittis a. Phasellus tincidunt purus quis urna vestibulum, sit amet pharetra urna vestibulum.\r\n\r\nVestibulum tincidunt risus ac mauris efficitur molestie. Suspendisse faucibus urna et eros interdum porttitor. Donec eu aliquam neque. Maecenas ac tempor risus, a bibendum metus. Cras lacinia porta purus non congue. Fusce vehicula pulvinar tellus, ac vehicula quam. Ut vulputate in nisl nec aliquet. Morbi porttitor eget ligula quis convallis. Integer mattis metus vitae quam iaculis, at ullamcorper justo vestibulum. Aliquam commodo odio ut lectus placerat, eget placerat quam elementum. Suspendisse quis tortor ante. Fusce auctor efficitur neque, sed faucibus justo gravida sit amet. Aliquam erat volutpat. Curabitur nec auctor lacus, sodales semper elit. Maecenas eu dictum ligula. Praesent auctor lectus pellentesque, luctus metus non, aliquet ligula.\r\n\r\nMaecenas pharetra fermentum libero vitae mattis. Aliquam eros metus, ultricies ut scelerisque eget, blandit sed nisl. Fusce egestas mollis purus. Nullam lacinia tincidunt lectus, ac elementum est ullamcorper id. In laoreet turpis id mi scelerisque scelerisque. Nullam fringilla luctus rhoncus. Aenean molestie dui eu consectetur finibus. Cras interdum semper dolor, nec congue nibh faucibus nec. Morbi quis ex in odio interdum sodales a faucibus quam. Nulla in pretium sapien, nec efficitur dolor. Nam ut mi vel lectus posuere consectetur. Vestibulum blandit aliquet enim id blandit. Vestibulum at elementum dui, eu molestie augue. Integer eu nisi nisl. Sed sit amet tempus neque. In accumsan, quam ac sollicitudin varius, lectus magna tempor neque, eget dignissim sem quam sit amet orci.\r\n\r\nSed sed lacinia justo, in faucibus eros. Etiam lacinia et libero in congue. Vestibulum eget nulla sit amet sapien congue ullamcorper sit amet eget ex. Phasellus malesuada nisl a neque elementum varius. Curabitur turpis libero, tristique id ipsum ac, egestas volutpat massa. Vestibulum volutpat efficitur enim, in viverra lacus ullamcorper fringilla. Suspendisse potenti. Fusce pulvinar accumsan erat, sed venenatis mi dignissim ac. Praesent bibendum lectus vel nunc porta, sed auctor lorem porttitor. Etiam rhoncus consectetur facilisis. Pellentesque lorem est, tincidunt tempus massa nec, venenatis vulputate ipsum. Vivamus nec est gravida lectus sodales vestibulum eu eget nunc. Morbi sit amet consequat ipsum. Quisque viverra lobortis dolor id commodo. Curabitur ornare sem non accumsan dictum.\r\n\r\nIn varius mi non tellus imperdiet, at dignissim justo venenatis. Fusce libero nulla, tincidunt at consectetur at, commodo eu dui. In varius sit amet arcu et semper. Phasellus imperdiet sapien nisl, a fermentum dolor ultricies tempus. Suspendisse ut sem congue, tempor lorem eget, lobortis libero. Vestibulum tempus maximus nisi at fringilla. Nullam in ligula ultricies, finibus elit vel, lacinia erat. Duis imperdiet faucibus quam.', '2023-05-10 07:21:35', '645b45ff5459c.png');
INSERT INTO `article` VALUES(6, 'Sixième article - 2', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer sit amet faucibus felis. In ut ipsum venenatis, pulvinar lorem eget, eleifend magna. Vestibulum at felis hendrerit sem varius dapibus. Curabitur aliquam lorem sed tortor dictum ullamcorper. In et sem lacus. Morbi eget ipsum massa. Cras gravida nulla ac feugiat maximus. Donec tristique, neque eget tempus cursus, tellus lorem pharetra justo, non porta elit ipsum in enim. Nunc fermentum euismod nunc sed sagittis. Suspendisse blandit odio et nibh rutrum vulputate. Pellentesque sit amet felis sit amet nunc faucibus mattis ut vel arcu. Ut sed lobortis ex, et laoreet felis. Aliquam hendrerit nibh vel vulputate vehicula. Pellentesque arcu mauris, maximus eget ligula vitae, semper convallis eros. Nam et nunc metus.\r\n\r\nVivamus fermentum vulputate dui nec consectetur. Aliquam non pellentesque massa. Cras auctor, mi et maximus laoreet, libero lacus aliquet ex, vitae vehicula purus libero at arcu. Donec sit amet massa tellus. Vestibulum lobortis semper placerat. Nullam volutpat a purus ut tristique. Praesent fermentum bibendum sem, a volutpat est lobortis et. In vitae tristique turpis. Donec luctus erat sed eros blandit rutrum. Praesent id hendrerit massa, eget iaculis elit. Etiam a volutpat libero, in suscipit justo. Pellentesque efficitur risus quis odio luctus, ac venenatis eros dapibus.\r\n\r\nFusce fringilla iaculis euismod. Sed ullamcorper, sapien sed accumsan eleifend, sem lorem cursus ligula, eget tincidunt leo diam nec lacus. Aenean finibus fermentum odio in laoreet. Sed vel sem mattis, posuere nisi non, finibus libero. Praesent in bibendum nulla. Nunc pulvinar in erat id tincidunt. In hac habitasse platea dictumst. Vestibulum fringilla mauris vel nisi ultrices scelerisque. Proin nec tortor et velit posuere posuere. In ac fermentum odio. Ut egestas enim varius, condimentum magna sed, aliquet turpis. Integer varius, dolor at egestas viverra, nisi leo volutpat ante, quis ullamcorper nisi sapien sed dui. Duis non nunc sit amet libero semper pretium eget ut massa. Donec rhoncus tortor non tortor dapibus venenatis et ut mi.\r\n\r\nQuisque bibendum, risus vel consequat scelerisque, lectus sapien rutrum erat, eu dapibus mauris tellus eu quam. Nulla in turpis nec justo fermentum hendrerit nec sit amet dui. Cras pulvinar nibh ipsum, non sagittis ligula venenatis pharetra. Proin in metus at lectus cursus sollicitudin. Morbi blandit urna felis, consectetur fringilla lectus sagittis quis. Praesent varius risus orci, quis tristique magna tincidunt a. Donec vulputate metus lorem, vitae rutrum justo semper placerat. Vestibulum tempor libero et dui commodo lacinia. Etiam vitae risus vitae mi tempor euismod. Nulla pretium mi mauris, non lobortis odio scelerisque eu. Donec eros lectus, placerat tristique euismod in, iaculis vel justo. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Morbi non metus eros.\r\n\r\nQuisque pellentesque leo at sagittis tristique. Aliquam tempor tempus dolor, non efficitur lorem tristique ac. Donec tempor mi velit, eget finibus nibh luctus sed. Cras sed tortor et ligula suscipit sagittis. Fusce placerat leo leo, ac tempus ipsum iaculis accumsan. Nullam consequat nunc id ex rutrum egestas. Aliquam dolor neque, suscipit sit amet fermentum ut, scelerisque nec magna. Vivamus arcu odio, laoreet eu odio non, ullamcorper sagittis sapien. Morbi risus leo, imperdiet a magna eget, aliquet facilisis arcu.', '2023-05-10 07:21:54', '645b5f1586e3d.png');
INSERT INTO `article` VALUES(7, 'Septième article', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec pellentesque et arcu quis vulputate. Aliquam fringilla est turpis, feugiat gravida turpis posuere ac. Cras laoreet tellus nec tempus euismod. Aenean quam mi, convallis nec sodales id, aliquam a nisl. Sed faucibus, quam quis interdum consequat, risus dui varius tortor, non semper quam nunc et felis. In vulputate fringilla sem sit amet vehicula. Cras velit orci, malesuada in nunc malesuada, mattis pulvinar nisl. Maecenas tortor ligula, feugiat a molestie vitae, mollis et metus.\r\n\r\nPraesent aliquet condimentum nunc, in ultrices metus lacinia eget. Nam at justo id mauris auctor volutpat. Nam feugiat semper hendrerit. Cras vehicula vel ligula at venenatis. Nunc maximus ac odio interdum eleifend. Quisque rhoncus eu ante at dignissim. Nunc eget mi in eros rutrum lacinia.\r\n\r\nSed egestas, nunc mollis porta aliquam, libero erat mattis erat, at sodales arcu lectus id ex. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Morbi at diam magna. Quisque ultricies turpis dui, at venenatis neque consectetur id. Vestibulum posuere molestie mauris vitae cursus. Ut id diam laoreet, condimentum elit ut, egestas nulla. Praesent molestie mauris in nisl ornare gravida. Quisque porta leo vitae viverra egestas. Etiam auctor turpis sit amet lectus viverra ultricies. Aliquam ac dignissim leo. Integer hendrerit nibh non dignissim cursus. Fusce efficitur convallis augue. Aenean ac massa ut quam maximus rhoncus. Cras leo urna, dignissim in ante vitae, ullamcorper fringilla ante.\r\n\r\nSed id tincidunt tortor, non blandit turpis. Etiam dictum rhoncus urna vitae interdum. Quisque accumsan, dolor pretium laoreet pulvinar, enim nunc cursus leo, ut egestas nisl magna quis justo. Praesent convallis odio in dui semper, non tempor ex malesuada. Aliquam erat volutpat. Aliquam posuere nisi vel suscipit feugiat. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Aenean posuere sed arcu sagittis blandit. Aliquam consectetur nulla at justo cursus, nec consectetur urna fermentum. Sed ut dignissim enim. Nunc a pulvinar diam, sit amet accumsan urna. Donec vestibulum velit finibus lorem finibus aliquet. Quisque tempor vestibulum odio, sit amet elementum eros blandit et. Nam finibus, libero at convallis condimentum, tellus leo pellentesque metus, vitae tincidunt libero est sed dolor.\r\n\r\nQuisque neque nisi, finibus quis porta vel, fringilla vel neque. Curabitur sodales lorem at pellentesque volutpat. Cras tellus ipsum, tristique quis cursus nec, feugiat eu urna. Duis rutrum rutrum lacus et scelerisque. Suspendisse ultrices velit sem, at tempus metus fringilla nec. Suspendisse lacinia, metus eu elementum dictum, justo sem pretium enim, eget aliquam lorem arcu quis magna. Quisque hendrerit convallis hendrerit. Nulla arcu elit, suscipit ac feugiat in, elementum a est. Phasellus metus lectus, mattis in diam nec, vestibulum tempor quam. Nullam id arcu ex. Praesent ultrices tristique purus, quis molestie metus tristique sed. Ut lacinia enim vel mi accumsan, id ullamcorper dolor hendrerit. In nec condimentum dolor, vel pellentesque arcu. Phasellus euismod vulputate felis.', '2023-05-10 07:22:13', '645b60b1097b6.png');

-- --------------------------------------------------------

--
-- Structure de la table `message`
--

DROP TABLE IF EXISTS `message`;
CREATE TABLE IF NOT EXISTS `message` (
  `id_message` int NOT NULL AUTO_INCREMENT,
  `prenom` varchar(255) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `mail` varchar(255) NOT NULL,
  `message` varchar(500) NOT NULL,
  PRIMARY KEY (`id_message`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `message`
--

INSERT INTO `message` VALUES(1, 'Jean-Louis', 'Errante', 'info@errantecreation.com', 'Mon super message !');
INSERT INTO `message` VALUES(2, 'John', 'Doe', 'info@errantecreation.com', 'Mon super message.\r\nOn test si ça s\'affiche sur plusieurs lignes.\r\n\r\nOn doit également tester si les accents fonctionnent bien.');

-- --------------------------------------------------------

--
-- Structure de la table `site`
--

DROP TABLE IF EXISTS `site`;
CREATE TABLE IF NOT EXISTS `site` (
  `id_site` int NOT NULL AUTO_INCREMENT,
  `title_site` varchar(255) NOT NULL,
  `description_site` varchar(500) NOT NULL,
  PRIMARY KEY (`id_site`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `site`
--

INSERT INTO `site` VALUES(1, 'Magnet Studio', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut justo enim, elementum eget nibh nec, rhoncus placerat orci.');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id_user` int NOT NULL AUTO_INCREMENT,
  `mail_user` varchar(255) NOT NULL,
  `pass_user` varchar(255) NOT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` VALUES(1, 'info@errantecreation.com', '$2y$10$QsMzlmWqyi4rH9thTKFlXO2Z0lU0OadmQJgHp0j5YhtV2a8WQ7R4S');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
